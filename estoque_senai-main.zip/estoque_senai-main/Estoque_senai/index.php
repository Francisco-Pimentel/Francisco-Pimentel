<!DOCTYPE html>
<html lang="pt">
<head>
    <link rel="stylesheet" href="login.css">
    <title>Login</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
</head>
<body>
    <div class ="login-page">
        <div class="form">
            <div class="login">
                <div class = "login-header">
                    
            
     </div>

     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Tela de login</title>

     <div class="background">
        <div class ="shape"></div>
        <div class ="shape"></div>
        </div>

    <form action="logar.php" method='post'>
        <label for="">Login</label>
        <input type="text" name="login" id="">
        <br>
        <label for="">Senha</label>
        <input type="password" name="senha" id="">
        <br>
        <input type="submit" value="login">
        
        <label for=""></label>

    </form>
<form action="cadastro_login.php">
        <input type="submit" class="btn btn-success" value="cadastrar login">
    </form>

     </div>

</body>
          
   </html>

              
          
     